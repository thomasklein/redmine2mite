class Mite::Account < Mite::SingletonBase
  
end