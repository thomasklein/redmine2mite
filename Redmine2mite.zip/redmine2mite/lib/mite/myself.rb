class Mite::Myself < Mite::SingletonBase
  
end