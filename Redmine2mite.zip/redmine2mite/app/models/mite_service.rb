class MiteService < MiteRsrc
end