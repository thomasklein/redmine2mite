class MiteProject < MiteRsrc
end